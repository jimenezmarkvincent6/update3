<?php
session_start(); // Start the session
include 'connection.php';

// Check if user is logged in
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

// Retrieve user information from the session
$fullname = $_SESSION['fullname'];
$role = $_SESSION['role'];
$user_id = $_SESSION['id']; // Get the logged-in user's ID

$sql = "SELECT profile_image FROM admin_staff WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id); // Bind the user ID to the query
$stmt->execute();
$stmt->bind_result($profile_image);
$stmt->fetch();
$stmt->close();

// If the profile image is empty, you can use a default image
if (empty($profile_image)) {
    $profile_image = 'path/to/default-image.jpg'; // Provide the path to a default image
}

// Close the database connection
$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
    
    <title>Parent Records</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet" />
    <link href="css/p_record.css" rel="stylesheet" />
    

</head>
<body>

<<div class="sidebar">
    <img src="logo/logo.png" alt="Logo">
        <a href="qr_scanner.php">Qr Code Scan</a>
        <a href="S_records.php">Student Records</a>
        <a href="P_records.php">Parent Records</a>
        <a href="U_records.php">Pick-Up Records</a>
        <div class="bottom-links">
            <a href="#">
                <i class="fas fa-cog"></i> Settings
            </a>
            <a href="#">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>
    <div class="main-content">
        <div class="header">
            <div class="user-info">
                <div class="notification">
                    <i class="fas fa-bell"></i>
                </div>
                <div class="vertical-rule"></div>
                <div class="profile">
                <img alt="User profile picture" height="40" src="https://oaidalleapiprodscus.blob.core.windows.net/private/org-Hh5RPsKhtBPsWCFSiEKnUJ6x/user-8qgiVpCV0U0b7zDjfFInHgjl/img-UaqtED2tWdF8Jj5BdVptvrvZ.png?st=2024-09-08T03%3A49%3A50Z&amp;se=2024-09-08T05%3A49%3A50Z&amp;sp=r&amp;sv=2024-08-04&amp;sr=b&amp;rscd=inline&amp;rsct=image/png&amp;skoid=d505667d-d6c1-4a0a-bac7-5c84a87759f8&amp;sktid=a48cca56-e6da-484e-a814-9c849652bcb3&amp;skt=2024-09-07T23%3A47%3A39Z&amp;ske=2024-09-08T23%3A47%3A39Z&amp;sks=b&amp;skv=2024-08-04&amp;sig=18zzyGV2lWaM/BQ7/LoacKemQW7r9eD1vJOq3I7Ssss%3D" width="40"/>
                <span><?php echo isset($_SESSION['user_name']) ? htmlspecialchars($_SESSION['user_name']) : 'Guest'; ?></span><br>
                <span><?php echo isset($_SESSION['user_role']) ? htmlspecialchars($_SESSION['user_role']) : 'Role not defined'; ?></span>
                </div>
            </div>
        </div>
    <hr/>
    <div class="table-container">
        <div class="search-bar-container">
        <div class="search-bar">
            <input type="text" id="search" placeholder="Search..." onkeyup="performSearch(event)">
            </div>
        </div>
        <?php
include 'connection.php';

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Pagination variables
$itemsPerPage = 10; // Items per page
$currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Current page from the URL
$currentPage = max(1, $currentPage); // Ensure current page is at least 1
$offset = ($currentPage - 1) * $itemsPerPage; // Offset for SQL query

$userRole = $_SESSION['role']; 

// Prepare the query for pagination
$stmt = $conn->prepare("SELECT id, fullname, contact_number, email, address FROM parent_acc LIMIT ?, ?");
$stmt->bind_param("ii", $offset, $itemsPerPage);
$stmt->execute();
$result = $stmt->get_result();

// Count total records for pagination
$totalResult = $conn->query("SELECT COUNT(*) as total FROM parent_acc");
$totalRow = $totalResult->fetch_assoc();
$totalItems = $totalRow['total'];
$totalPages = ceil($totalItems / $itemsPerPage); // Calculate total pages

// HTML Table
echo '<table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Contact Number</th>
                <th>Email Address</th>
                <th>Address</th>
                <th style="text-align: center;">Action</th>
            </tr>
        </thead>
        <tbody>';

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '<tr>
        <td>' . htmlspecialchars($row['fullname']) . '</td>
        <td>' . htmlspecialchars($row['contact_number']) . '</td>
        <td>' . htmlspecialchars($row['email']) . '</td>
        <td>' . htmlspecialchars($row['address']) . '</td>
        <td style="text-align: center;">
            <button class="view-btn" title="View" onclick="showChildInfo(' . htmlspecialchars($row['id']) . ')">
                <i class="fas fa-eye"></i> 
            </button>
        </td>
      </tr>';

    }
} else {
    echo '<tr><td colspan="5">No records found</td></tr>';
}

echo '  </tbody>
      </table>';



// Close the database connection
$stmt->close();
$conn->close();
?>
<!-- Combined Modals -->
<div id="edit-overlay" class="modal-edit" style="display: none;">
    <div class="modal-contentss">
        <span class="close" id="edit-close-btn">&times;</span>
        <h2>Edit User Information</h2>
        <form id="edit-form" action="edit_user.php" method="post">
            <input type="hidden" id="edit_user_id" name="user_id">
            <div class="form-group">
                <label for="edit_fullname">Full Name:</label>
                <input type="text" id="edit_fullname" name="fullname" required>
            </div>
            <div class="form-group">
                <label for="edit_contactnumber">Contact Number:</label>
                <input type="tel" id="edit_contactnumber" name="contact_number" required>
            </div>
            <div class="form-group">
                <label for="edit_email">Email:</label>
                <input type="email" id="edit_email" name="email" required>
            </div>
            <div class="form-group">
                <label for="edit_address">Address:</label>
                <input type="text" id="edit_address" name="address" required>
            </div>
            <div class="form-group">
                <label for="edit_password">Password:</label>
                <input type="password" id="edit_password" name="password">
            </div>
            <div class="form-group">
                <label for="edit_confirm_password">Confirm Password:</label>
                <input type="password" id="edit_confirm_password" name="confirm_password">
            </div>
            <button type="submit" class="submit-btn">Update</button>
        </form>
    </div>
</div>
<style>
    .view-btn {
        border: none;
        padding: 8px 15px;
        border-radius: 5px;
        cursor: pointer;
    }
    .view-btn:hover {
        transform: scale(1.05); /* Slight zoom effect */
    }
    .view-btn i {
        font-size: 16px; /* Adjust icon size */
    }
</style>

<div id="childInfoModal" class="modal-edit" style="display: none;">
    <div class="modal-contentss">
        <span class="close" onclick="closeModal()">&times;</span>
        <h3>Student Information</h3>
        <div class="student-info">
            <!-- Dynamic Student Info -->
        </div>
    </div>
</div>

<!-- Enhanced Styles -->
<style>
/* Reuse existing styles and enhance */
.modal-edit {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.7);
    backdrop-filter: blur(5px);
    animation: fade-in 0.3s ease-in-out;
}
.modal-contentss {
    background-color: #f9f9f9;
    margin: 5% auto;
    padding: 30px;
    width: 90%;
    max-width: 600px;
    border-radius: 12px;
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
    animation: slide-in 0.3s ease-out;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    color: #333;
    position: relative;
    overflow: hidden;
}
.close {
    color: #888;
    position: absolute;
    right: 15px;
    top: 15px;
    font-size: 24px;
    font-weight: bold;
    cursor: pointer;
    transition: color 0.3s;
}
.close:hover {
    color: #ff6b6b;
}
h2, h3 {
    font-size: 24px;
    font-weight: bold;
    text-align: center;
    color: #2c3e50;
    margin-bottom: 20px;
    border-bottom: 2px solid #e5e5e5;
    padding-bottom: 10px;
}
.form-group {
    margin-bottom: 20px;
}
.form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: bold;
    color: #555;
    font-size: 14px;
}
.form-group input,
.form-group textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 8px;
    font-size: 14px;
    background-color: #fff;
    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);
    transition: all 0.3s ease;
}
.form-group input:focus,
.form-group textarea:focus {
    border-color: #007bff;
    outline: none;
    box-shadow: 0 0 8px rgba(0, 123, 255, 0.5);
}
.submit-btn {
    background: linear-gradient(to right, #3498db, #2980b9);
    color: #fff;
    border: none;
    padding: 12px;
    font-size: 16px;
    font-weight: bold;
    border-radius: 8px;
    cursor: pointer;
    width: 100%;
    margin-top: 15px;
    transition: background 0.3s, transform 0.2s;
}
.submit-btn:hover {
    background: linear-gradient(to right, #2980b9, #3498db);
    transform: translateY(-2px);
}
.submit-btn:active {
    transform: translateY(0);
}
@keyframes fade-in {
    from { opacity: 0; }
    to { opacity: 1; }
}
@keyframes slide-in {
    from {
        transform: translateY(-20px);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}
</style>

<!-- Scripts (merged functionalities) -->
<script>
// Open Edit Modal for User
// Open Edit Modal for User
function openEditModal(userId, fullname, contactNumber, email, address) {
    document.getElementById('edit_user_id').value = userId;
    document.getElementById('edit_fullname').value = fullname;
    document.getElementById('edit_contactnumber').value = contactNumber;
    document.getElementById('edit_email').value = email;
    document.getElementById('edit_address').value = address;

    document.getElementById('edit-overlay').style.display = 'block';
}

// Close Edit Modal
document.getElementById('edit-close-btn').addEventListener('click', function () {
    document.getElementById('edit-overlay').style.display = 'none';
    document.getElementById('edit-form').reset();
});

// Close on Outside Click
window.onclick = function (event) {
    const modal = document.getElementById('edit-overlay');
    if (event.target === modal) {
        modal.style.display = 'none';
        document.getElementById('edit-form').reset();
    }
};

// Handle Edit Form Submission
async function handleEditFormSubmission(event) {
    event.preventDefault(); // Prevent default form submission

    const form = event.target; // Get the form element
    const formData = new FormData(form); // Prepare form data for submission

    try {
        const response = await fetch(form.action, {
            method: 'POST',
            body: formData,
        });

        if (!response.ok) {
            // Handle HTTP errors (e.g., 404, 500)
            throw new Error(`HTTP Error: ${response.status}`);
        }

        const data = await response.json(); // Parse JSON response

        if (data.success) {
            // Show success message and reload the page
            alert(data.message || 'Information updated successfully.');
            window.location.reload();
        } else {
            // Show server-side validation error message
            alert(data.message || 'An error occurred while updating information.');
        }
    } catch (error) {
        // Log and show network or unexpected errors
        console.error('Error:', error.message);
        alert('Failed to update information.');
    }
}

// Attach submit handler to the edit form
document.getElementById('edit-form').addEventListener('submit', handleEditFormSubmission);

// Open Child Info Modal
function openModal() {
    const modal = document.getElementById('childInfoModal');
    modal.style.display = 'block'; // Display the modal
}

// Close Child Info Modal
function closeModal() {
    const modal = document.getElementById('childInfoModal');
    modal.style.display = 'none'; // Hide the modal
}


// Event listener for outside click
window.onclick = function(event) {
    const modal = document.getElementById('childInfoModal');
    if (event.target === modal) {
        closeModal();
    }
};

// Debug fetch example
function showChildInfo(parentId) {
    console.log('Fetching data for parent ID:', parentId);
    fetch(`child_info.php?parent_id=${parentId}`)
        .then(response => response.text())
        .then(html => {
            const container = document.querySelector('.student-info');
            container.innerHTML = html || '<p>No data available</p>';
            openModal();
        })
        .catch(err => {
            console.error('Error fetching child info:', err);
            alert('Failed to load child information.');
        });
}


</script>


            <div class="pagination" id="pagination"></div>
    <script>
        const totalItems = <?php echo $totalItems; ?>; 
        const itemsPerPage = <?php echo $itemsPerPage; ?>; 
        let currentPage = <?php echo $currentPage; ?>; 

        function renderPagination() {
            const pagination = document.getElementById('pagination');
            pagination.innerHTML = ''; // Clear previous pagination

            const totalPages = Math.ceil(totalItems / itemsPerPage);

            // Previous button
            const prevLink = document.createElement('a');
            prevLink.innerHTML = '«';
            prevLink.className = currentPage === 1 ? 'disabled' : '';
            prevLink.onclick = function() {
                if (currentPage > 1) {
                    currentPage--;
                    updatePage();
                }
            };
            pagination.appendChild(prevLink);

            // Page numbers
            for (let i = 1; i <= totalPages; i++) {
                const pageNumber = document.createElement('div');
                pageNumber.innerHTML = i;
                pageNumber.className = `page-number ${i === currentPage ? 'active' : ''}`;
                pageNumber.onclick = function() {
                    currentPage = i;
                    updatePage();
                };
                pagination.appendChild(pageNumber);
            }

            // Next button
            const nextLink = document.createElement('a');
            nextLink.innerHTML = '»';
            nextLink.className = currentPage === totalPages ? 'disabled' : '';
            nextLink.onclick = function() {
                if (currentPage < totalPages) {
                    currentPage++;
                    updatePage();
                }
            };
            pagination.appendChild(nextLink);
        }

        function updatePage() {
            window.location.href = '?page=' + currentPage; // Redirect to the correct page
        }

        // Initial rendering
        renderPagination();
    </script>
            </div>
        </div>
    </div>

    <script src="script/script.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<!-- Loading Spinner -->
<div id="loader" class="loader" style="display: none;">
    <div class="spinner"></div>
</div>
</body>
</html>
